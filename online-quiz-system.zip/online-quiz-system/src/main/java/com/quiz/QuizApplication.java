package com.quiz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.quiz.model.Question;
import com.quiz.repository.QuestionRepository;

import jakarta.annotation.PostConstruct;

@SpringBootApplication
public class QuizApplication {

    @Autowired
    private QuestionRepository repo;

    public static void main(String[] args) {
        SpringApplication.run(QuizApplication.class, args);
    }

    @PostConstruct
    public void loadData() {
        if (repo.count() == 0) {

            Question q1 = new Question();
            q1.setQuestion("What is Java?");
            q1.setOptionA("Language");
            q1.setOptionB("Car");
            q1.setOptionC("Food");
            q1.setOptionD("Game");
            q1.setCorrectAnswer("A");

            Question q2 = new Question();
            q2.setQuestion("What is 2 + 2?");
            q2.setOptionA("3");
            q2.setOptionB("4");
            q2.setOptionC("5");
            q2.setOptionD("6");
            q2.setCorrectAnswer("B");

            Question q3 = new Question();
            q3.setQuestion("Which is programming language?");
            q3.setOptionA("HTML");
            q3.setOptionB("Java");
            q3.setOptionC("CSS");
            q3.setOptionD("Photoshop");
            q3.setCorrectAnswer("B");

            repo.save(q1);
            repo.save(q2);
            repo.save(q3);
        }
    }
}