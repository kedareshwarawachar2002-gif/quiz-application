
package com.quiz.controller;

import com.quiz.model.Question;
import com.quiz.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
public class QuizController {

    @Autowired
    private QuizService service;

    @GetMapping("/")
    public String quizPage(Model model) {
        model.addAttribute("questions", service.getAllQuestions());
        return "quiz";
    }

    @PostMapping("/submit")
    public String submitQuiz(@RequestParam Map<String, String> answers, Model model) {

        int score = 0;
        List<Question> questions = service.getAllQuestions();

        for (Question q : questions) {
            String ans = answers.get("q" + q.getId());
            if (q.getCorrectAnswer().equals(ans)) {
                score++;
            }
        }

        model.addAttribute("score", score);
        model.addAttribute("total", questions.size());

        return "result";
    }
}
